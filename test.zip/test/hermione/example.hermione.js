const { assert } = require('chai');

describe('общие требования', async function() {
    it('верстка должна адаптироваться под ширину', async function() {
        const puppeter = await this.browser.getPuppeteer();
        const[page] = await this.puppeteer.pages();
        await this.browser.url('http://localhost:3000/hw/store');
        await page.waitForTimeout(5000);
        await this.browser.assertView('plain', '.navbar');
        console.log('end');

    });
});
