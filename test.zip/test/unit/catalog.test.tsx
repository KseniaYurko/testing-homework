import React from 'react'
import axios from 'axios'
import mockProducts from '../helpers/mocks/mockProducts';
import renderTestApp from '../helpers/renderTestApp';
import '@testing-library/jest-dom'

jest.mock('axios');

describe('Тестирование требований каталога', () => {
    test('Каталог должен отображать данные с сервера', () => {
        const response = mockProducts;

        (axios.get as jest.Mock).mockResolvedValue(response);
        const { findByTestId } = renderTestApp({ initialRoute: "/catalog" });

        response.data.forEach(async (value) => {
            const item = await findByTestId(`${value.id}`);
            expect(item).toBeInTheDocument();
        });
    });

    test('Для каждого товара в каталоге отображается название, цена и ссылка на страницу с подробной информацией о товаре', () => {
        const response = mockProducts;

        (axios.get as jest.Mock).mockResolvedValue(response);
        const { findByTestId } = renderTestApp({ initialRoute: "/catalog" });

        response.data.forEach(async (value) => {
            const item = await findByTestId(`${value.id}`);
            expect(item).toBeInTheDocument();

            const name = item.querySelector('.ProductItem-Name');
            const price = item.querySelector('.ProductItem-Price');
            const link = item.querySelector('.ProductItem-DetailsLick');

            expect(name).toHaveTextContent(value.name);
            expect(price).toHaveTextContent(`${value.price}`);
            expect(link).toHaveAttribute("href", `/catalog/${value.id}`);
        })

    })



});