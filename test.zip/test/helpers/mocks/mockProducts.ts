export default {
    data: [
        {
            id: 1,
            name: 'first_product',
            price: 100,
        },
        {
            id: 2,
            name: 'second_product',
            price: 200,
        },
        {
            id: 3,
            name: 'third_product',
            price: 300,
        },
        {
            id: 4,
            name: 'fourth_product',
            price: 400,
        },
        {
            id: 5,
            name: 'fifth_product',
            price: 500,
        },
    ]
}